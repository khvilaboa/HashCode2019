
import argparse
from models import *
import re

class Handler:
    def __init__(self, filename):
        self.photos = []
        self.hphotos = []
        self.vphotos = []
        self.slideshow = None

        with open(filename, 'r') as f:
            self.num_photos = f.readline()
            ind = 0

            for line in f.readlines():
                match = re.match("(H|V) ([0-9]+) (.*)", line)
                if match:
                    orientation, num_tags, tags = match.groups()
                    photo = Photo(ind, set(tags.split()), orientation is 'H')
                    self.photos.append(photo)
                    ind += 1

                    if orientation is 'H':
                        self.hphotos.append(photo)
                    else:
                        self.vphotos.append(photo)

    def output(self, filename):
        if self.slideshow:
            with open(filename, 'w') as f:
                f.write(str(len(self.slideshow.slides)) + "\n")
                for slide in self.slideshow.slides:
                    f.write(slide.to_output_file() + "\n")

    def b_create_slideshow_bruteforce(self):
        slide_set = set()
        for photo in self.photos:
            slide_set.add(Slide(photo))
        return self.create_slideshow_bruteforce(slide_set)

    def generic_create_slideshow_bruteforce(self):
        return self.create_slideshow_bruteforce({Slide(photo) for photo in self.hphotos})

    def create_slideshow_bruteforce(self, slide_set):
        slideshow = SlideShow()
        current_slide = slide_set.pop()
        slideshow.append(current_slide)
        i = 0
        while len(slide_set) > 0:
            best_match = None   
            best_match_points = -1
            for candidate in slide_set:
                points = current_slide.interest_factor(candidate)
                if points > best_match_points:
                    best_match = candidate
                    best_match_points = points
            current_slide = best_match
            slide_set.remove(best_match)
            slideshow.append(best_match)
            i += 1
            if i % 100 == 0:
                print(i)

        self.slideshow = slideshow

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='HashCode 2019 submission for the online qualification round')

    parser.add_argument('input_filename', action='store', help='Input file path.')
    parser.add_argument('-o', '--output_filename', action='store', help='Output file pah')
    parser.add_argument('-f', '--function', action='store', default=None, help='Function')
    # parser.add_argument('-e', '--example', action='store', default = 0, type = int, help='Example 1')
    # parser.add_argument('-b', '--bool_value', action='store_true', help='Example 1')
    args = parser.parse_args()

    handler = Handler(args.input_filename)

    if args.function:
        handler.b_create_slideshow_bruteforce()
    else:
        getattr(handler, args.function)()

    handler.output("test.txt")

    # ...
    #handler.output(args.output_filename)
